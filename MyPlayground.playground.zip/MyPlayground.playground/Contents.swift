//: Playground - noun: a place where people can play

import UIKit

var str : String = "Hello "
//implicit type string (: String is not needed, just tells coder what type of variable it is)

let programmingLanguage: String = "Swift"
//let is a constant; the value can be used and seen but not changed

var greeting = "\(str) \(programmingLanguage)"


print("To build an iphone app we need to learn \(programmingLanguage)")
// the use of (\) instead of a (+) is string interpolation























